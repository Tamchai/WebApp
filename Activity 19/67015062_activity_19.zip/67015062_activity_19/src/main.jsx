import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'

import FoodVoting from './component/footvoting.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <FoodVoting />
  </StrictMode>,
)
