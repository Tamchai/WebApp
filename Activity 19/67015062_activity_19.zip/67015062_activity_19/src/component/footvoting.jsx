import React, { useState } from "react";

const FoodCard = ({title,subtitle,description,img,onVote,votes}) => {
  const handleVote = () => {
    if (votes < 10){
      onVote(1);
    }else{
      alert("Cannot Vote more");
    }
  }
  const handleUnvote = () => {
    if (votes > 0){
      onVote(-1);
    }else{
      alert("Cannot unvote");
    }
  };
  return (
    <div className="card">
      <div className="card-main">
        <div className="card-content">
          <h2 className="card-title">{title}</h2>
          <h3 className="card-subtitle">{subtitle}</h3>
          <h3 className="card-description">{description}</h3>
        </div>

        <img src={img} alt={title} className="card-img" />
      </div>

      <div className="vote-section">
        <button className="btn" onClick={handleVote}>Click to Vote</button>
        <span className="vote-box">{votes === 0 ? "MIN" : votes === 10 ? "MAX" : votes}</span>
        <button className="btn" onClick={handleUnvote}>Click to Unvote</button>
      </div>
    </div>
  );
};

const FootVoting = () => {
  const [votes, setVotes] = useState({ food1: 0, food2: 0, food3: 0, food4: 0});

  const handleVote = (food, value) => {
    let newValue = votes[food] + value;
    if (newValue < 0) newValue = 0;
    if (newValue > 10) newValue = 10;

    setVotes({
      ...votes,
      [food]: newValue
    });
  };
  return (
    <div className="container">
      <style>{`
        body {
          margin: 0;
          font-family: 'Athiti', sans-serif;
          background: #555;
          display: flex;
          justify-content: center;
        }

        .container {
          min-height: 100vh; 
          display: flex;
          flex-direction: column;
          align-items: center;
          padding: 20px;
        }

        .header {
          font-size: 36px;
          font-weight: bold;
          color: #ffcc00;
          margin-bottom: 30px;
        }

        .card {
          display: flex;
          flex-direction: column;
          background: #f7e5ca;
          border: 1px solid #000;
          border-radius: 12px;
          padding: 15px;
          width: 1000px;
          margin-bottom: 10px;
          box-shadow: 4px 4px 12px rgba(0,0,0,0.2);
        }
        .card-main {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 15px; 
        }
        .card-content {
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          flex: 1;
          padding-right: 15px;
        }

        .card-title {
          font-size: 20px;
          font-weight: bold;
          color: #444;
          margin-bottom: 4px;
        }

        .card-subtitle {
          font-size: 18px;
          font-weight: 600;
          color: #444;
          margin-bottom: 4px;
        }

        .card-description {
          font-size: 18px;
          font-weight: 400;
          color: #222;
          margin-bottom: 8px;
        }
        .card-img {
          width: 350px;
          height: auto;
          border-radius: 5px;
        }
        .vote-section {
          display: flex;
          justify-content: center;
          align-items: center;
          gap: 10px;
          margin-top: 10px;
        }

        .btn {
          color: #222;
          font-weight: 600;
          padding: 8px 16px;
          border: 1px solid #222;
          border-radius: 8px;
          background: #fff;
          cursor: pointer;
          box-shadow: 0 3px 6px rgba(0,0,0,0.2);
        }

        .vote-box {
          padding: 6px 18px;
          background-color: #4add4aff;
          color: #c300ffff;
          font-size: 24px;
          font-weight: bold;
          border: 2px solid #8400acff;
          border-radius: 6px;
          min-width: 50px;
          text-align: center;
        }
        `}
      </style>
      <h1 className="header">โหวตอาหาร</h1>
      <FoodCard 
        title="อาหารคาว"
        subtitle="ข้าวผัด"
        description="Fried rice is a dish of cooked rice that has been stir-fried in a wok or a frying pan and is usually mixed with other ingredients such as eggs, vegetables, seafood, or meat. It is often eaten by itself or as an accompaniment to another dish. Fried rice is a popular component of East Asian, Southeast Asian and certain South Asian cuisines. As a homemade dish, fried rice is typically made with ingredients left over from other dishes, leading to countless variations. Fried rice first developed during the Sui dynasty in China"
        img="https://img.wongnai.com/p/1920x0/2019/12/19/d5537700a7274ac09964b6a51dd0a9f6.jpg"
        votes={votes.food1}
        onVote={(val) => handleVote("food1", val)}
        />
      <FoodCard 
        title="อาหารหวาน"
        subtitle="บัวลอย"
        description="Bua loi or bua loy is a Thai dessert. It consists of rice flour rolled into small balls, and cooked in coconut milk and sugar.Some Bua loi also adds sweet egg into the recipe. It was inspired by Tangyuan, a Chinese dessert that is traditionally eaten around the Lantern festival. Bua Loi is also traditionally eaten during the Dongzhi Festival in Thailand, which is a festival for the Chinese-Thai bloodline. There are a variety of versions of Bua loi such as ones that use food coloring instead of natural color, use soy milk instead of Coconut cream, add sliced pumpkin inside the rice balls, et cetera. There are other types of Bua loi from other countries such as China, Japan, Indonesia, Myanmar, Philippines, Southern Vietnam and Malaysia."
        img="https://f.ptcdn.info/557/035/000/1442537793-IMG34862-o.jpg"
        votes={votes.food2}
        onVote={(val) => handleVote("food2", val)}
        />
            <FoodCard 
        title="อาหารคาว"
        subtitle="แฮมเบอร์เกอร์"
        description="They say you’re never supposed to meet your idols. In this case, it’s a good thing your idol is inanimate.
                    Cheeseburgers are never going to give you up or let you down. They’ll also never run around or desert you.
                    They’ll never make you cry, unless it’s from sheer joy. Cheeseburgers certainly won’t say goodbye either.
                    Finally, cheeseburgers are incapable of telling lies or hurting you. On the flip side, they can still Rick Roll you."
        img="https://static.thairath.co.th/media/BUCz3kW7pmsIQUeyCY3t70tNCfEpKVQYHOtYC4HikHoozpO8zUpuqWq1B.jpg"
        votes={votes.food3}
        onVote={(val) => handleVote("food3", val)}
        />
      <FoodCard 
        title="อาหารหวาน"
        subtitle="ลอดช่องสิงคโปร์"
        description="Cendol is an iced sweet dessert that contains pandan-flavoured green rice flour jelly,coconut milk, and palm sugar syrup. It is popular in the Southeast Asian nations of Indonesia, Malaysia,Brunei, Cambodia, East Timor, Laos, Vietnam, Thailand, Singapore, Philippines, and Myanmar. Next to the green jelly, additional toppings might be added, including diced jackfruit, sweetened red azuki beans,or durian."
        img="https://i.ytimg.com/vi/Mwt-7UAjUxo/maxresdefault.jpg"
        votes={votes.food4}
        onVote={(val) => handleVote("food4", val)}
        />
    </div>
  );
};

export default FootVoting;