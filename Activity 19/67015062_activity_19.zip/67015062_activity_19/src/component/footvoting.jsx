import React, { useState } from "react";

const FoodCard = ({title,subtitle,description,img,onVote,votes}) => {
  const handleVote = () => {
    if (votes < 10){
      onVote(1);
    }else{
      alert("Cannot Vote more");
    }
  }
  const handleUnvote = () => {
    if (votes > 0){
      onVote(-1);
    }else{
      alert("Cannot unvote");
    }
  };
  return (
    <div className="card">
      <div className="card-main">
        <div className="card-content">
          <h2 className="card-title">{title}</h2>
          <h3 className="card-subtitle">{subtitle}</h3>
          <h3 className="card-description">{description}</h3>
        </div>

        <img src={img} alt={title} className="card-img" />
      </div>

      <div className="vote-section">
        <button className="btn" onClick={handleVote}>Click to Vote</button>
        <span className="vote-box">{votes === 0 ? "MIN" : votes === 10 ? "MAX" : votes}</span>
        <button className="btn" onClick={handleUnvote}>Click to Unvote</button>
      </div>
    </div>
  );
};

const FootVoting = () => {
  const [votes, setVotes] = useState({ food1: 0, food2: 0, food3: 0, food4: 0});

  const handleVote = (food, value) => {
    let newValue = votes[food] + value;
    if (newValue < 0) newValue = 0;
    if (newValue > 10) newValue = 10;

    setVotes({
      ...votes,
      [food]: newValue
    });
  };
  return (
    <div className="container">
      <style>{`
        body {
          margin: 0;
          font-family: 'Athiti', sans-serif;
          background: #555;
          display: flex;
          justify-content: center;
        }

        .container {
          min-height: 100vh; 
          display: flex;
          flex-direction: column;
          align-items: center;
          padding: 20px;
        }

        .header {
          font-size: 48px;
          font-weight: bold;
          color: #ffcc00;
          margin-bottom: 30px;
        }

        .card {
          display: flex;
          flex-direction: column;
          background: #f7e5ca;
          border: 1px solid #000;
          border-radius: 12px;
          padding: 15px;
          width: 1000px;
          margin-bottom: 10px;
          box-shadow: 4px 4px 12px rgba(0,0,0,0.2);
        }
        .card-main {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;

        }
        .card-content {
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          flex: 1;
          padding-right: 15px;
        }

        .card-title {
          font-size: 32px;
          font-weight: bold;
          color: #444;
          margin-bottom: 4px;
        }

        .card-subtitle {
          font-size: 18px;
          font-weight: 600;
          color: #444;
          margin-bottom: 4px;
        }

        .card-description {
          font-size: 18px;
          font-weight: 400;
          color: #222;
          margin-bottom: 8px;
          line-height: 1.8;
        }
        .card-img {
          width: 250px;
          height: auto;
          object-position: right top;
          border-radius: 5px;
        }
        .vote-section {
          display: flex;
          justify-content: center;
          align-items: center;
          gap: 10px;
          margin-top: 10px;
        }

        .btn {
          color: #222;
          font-weight: 600;
          padding: 8px 16px;
          border: 1px solid #222;
          border-radius: 8px;
          background: #fff;
          cursor: pointer;
          box-shadow: 0 3px 6px rgba(0,0,0,0.2);
        }

        .vote-box {
          padding: 6px 18px;
          background-color: #78e300;
          color: #c300ffff;
          font-size: 24px;
          font-weight: bold;
          border: 2px solid #8400acff;
          border-radius: 6px;
          min-width: 50px;
          text-align: center;
        }
        `}
      </style>
      <h1 className="header">โหวตอาหาร</h1>
      <FoodCard 
        title="อาหารคาว"
        subtitle="ข้าวผัด"
        description="Fried rice is a dish of cooked rice that has been stir-fried in a wok or a frying pan and is usually mixed with other ingredients such as eggs, vegetables, seafood, or meat. It is often eaten by itself or as an accompaniment to another dish. Fried rice is a popular component of East Asian, Southeast Asian and certain South Asian cuisines. As a homemade dish, fried rice is typically made with ingredients left over from other dishes, leading to countless variations. Fried rice first developed during the Sui dynasty in China"
        img="https://scontent.fbkk18-2.fna.fbcdn.net/v/t1.6435-9/114008693_1704572053044688_8399614024902892116_n.jpg?_nc_cat=104&ccb=1-7&_nc_sid=833d8c&_nc_ohc=U_LLn2s-ma4Q7kNvwHc5qb2&_nc_oc=Adl3loa3MkPRtMlRjh40MpUR1LUL-4zf5Urqj7IuO35h4stab8Yn9NfCm2jLNZV7rvU&_nc_zt=23&_nc_ht=scontent.fbkk18-2.fna&_nc_gid=Yn-yvF4jO59MaaQJCxur1w&oh=00_AfXM7RJzxNRj6WoY9mePhu51YRKy_q4WKMyRebQsQj7onQ&oe=68DCDB26"
        votes={votes.food1}
        onVote={(val) => handleVote("food1", val)}
        />
      <FoodCard 
        title="อาหารหวาน"
        subtitle="บัวลอย"
        description="Bua loi or bua loy is a Thai dessert. It consists of rice flour rolled into small balls, and cooked in coconut milk and sugar.Some Bua loi also adds sweet egg into the recipe. It was inspired by Tangyuan, a Chinese dessert that is traditionally eaten around the Lantern festival. Bua Loi is also traditionally eaten during the Dongzhi Festival in Thailand, which is a festival for the Chinese-Thai bloodline."
        img="https://i.postimg.cc/bJf7wG3S/Screenshot-2025-09-01-181303.png"
        votes={votes.food2}
        onVote={(val) => handleVote("food2", val)}
        />
    </div>
  );
};

export default FootVoting;